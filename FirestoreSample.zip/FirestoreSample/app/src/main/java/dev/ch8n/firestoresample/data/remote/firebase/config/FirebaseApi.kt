package dev.ch8n.firestoresample.data.remote.firebase.config

object FirebaseApi {
}