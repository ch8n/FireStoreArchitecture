package dev.ch8n.firestoresample.ui

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import dev.ch8n.firestoresample.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
