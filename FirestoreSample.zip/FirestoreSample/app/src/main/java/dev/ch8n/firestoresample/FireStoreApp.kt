package dev.ch8n.firestoresample

import android.app.Application

class FireStoreApp : Application() {

    override fun onCreate() {
        super.onCreate()


    }
}